#include <stdio.h>
int main()
{
    setvbuf(stdout,0,2,0);
    setvbuf(stdin,0,2,0);
    setvbuf(stderr,0,2,0);
    char name[0x28];
    long long namelen;
    char text[0x100];
    printf("Gift %p\n",text);
    printf("How long is your name: ");
    scanf("%lld",&namelen);
    printf("Please input your name: ");
    //gets(name);
    read(0,name,namelen);
    printf("Your name: ");
    puts(name);
    printf("How long is your title: ");
    scanf("%lld",&namelen);
    printf("Please input title: ");
    read(0,name,namelen);
    printf("Please input message: ");
    read(0,text,0xFF);
    printf("Your Message: %s\n",text);
    return 0;
}